<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('formSubmit', 'Prescription@submit');

Route::get('d-details', 'Prescription@doctor_details');

Route::get('d-det/{id}', 'Prescription@doc_det');

Route::get('medicine_det/{val}', 'Prescription@medicine_details');

Route::get('med_data/{id}', 'Prescription@medicine_data');

Route::get('data', 'Prescription@get_data_to_Convert');

Route::get('download', 'Prescription@downloadPDF');