<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Prescription extends Controller
{
   
    function index() {
    	echo "hello word";
    }

    

    function doctor_details() {
    	$detail = DB::table('d_name')->select(array('id','name'))->get();
    	// $result = DB::select(DB::raw('select * from d_name'));
    	// echo "<pre>";
    	// print_r($result);
    	return view('home')->with('detail', $detail);
    }

    public function doc_det($id){
    	echo json_encode(DB::table('d_name')->where('id', $id)->get());
    }

    public function medicine_details($val)
    {
    	echo json_encode(DB::table('medicine')->select(array('id','medicine-name'))->where('medicine-name', 'LIKE', "%$val%")->get());
    	// $detail = DB::table('medicine')->select(array('id','medicine-name'))->get();
    	// return view('home')->with('tab_name', $detail);

    	// $detail = DB::table('medicine')->select(array('id','medicine-name'))->where('medicine-name', 'LIKE', "%$val%")->get();

    	// return $detail;
    }
    public function medicine_data($id)
    {
    	echo json_encode(DB::table('medicine')->where('id', $id)->get());
    	
    }

    function submit(Request $request) {
    	
    	$name = $request->post('p-name');
    	$address = $request->post('p-add');
    	$number = $request->post('p-number');
    	// $sex = $request->post('');
    	$sex = 'male';
    	$age = $request->post('p-age');
    	$weight = $request->post('p-weight');
    	$m_id = $request->post('m-name-id');
    	$dr_id = $request->post('d-name-id');


    	// $data = array('dr-id'=>$dr_id,'m-id'=>$m_id);
    	// DB::table('prescription_no')->insert($data); working fine

    	$p_no = DB::table('prescription_no')->max('p-id');

    	$patient_data = array('name'=>$name,'address'=>$address, 'number'=>$number, 'sex'=>$sex, 'age'=>$age,'weight'=>$weight,'p-no'=>$p_no);
    	DB::table('patient_details')->insert($patient_data); 


    	return $request->post();

    }

    function get_data_to_Convert()
    {
    	$result = DB::select(DB::raw('select p.name as p_name, p.address as p_add, p.number as p_num, p.sex as p_sex, p.age as p_age, p.weight as p_weight, d.name as d_name, d.qualification as d_qua, d.address as d_add, d.contact as d_cont, d.regi_no as d_reg, m.medicine-name, strength, dosage-form, d-instruction, quantity from patient_details p, d_name d, medicine m , prescription_no pn where pn.p-id = p.p-no and d.id = pn.dr_id and m.id = pn.m-id'));

    	echo "<pre>";
    	print_r($result);
    }
}
