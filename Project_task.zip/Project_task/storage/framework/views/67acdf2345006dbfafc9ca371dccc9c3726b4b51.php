<!DOCTYPE html>
<html>
<head>
    <title>Dr Prescription</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">


    <!-- normal style -->
    <style type="text/css">
        input.form-control.w-10, select.custom-select.w-10 {
            width: 250px;
        }
        select.custom-select.w-30 {
            width: 190px;
        }
        input.form-control.w-30 {
            width: 80%;
        }
        textarea {
            width: 235px;
            height: 75px;
        }

        .table-bordered td, .table-bordered th {
             border: none; 
        }


    /*medicine style*/
        input.form-control.w-big {
            width: 400px;
        }
        input.form-control.w-small {
            width: 100%;
        }

        #searchResult{
         list-style: none;
         padding: 0px;
         width: 400px;
         position: absolute;
         margin: 0;
         top: 47px;
        }

        #searchResult li{
         background: lavender;
         padding: 4px;
         margin-bottom: 1px;
        }

        /*#searchResult li:nth-child(even){
         background: cadetblue;
         color: white;
        }*/

        #searchResult li:hover{
         cursor: pointer;
        }

        input[type=text]{
         padding: 5px;
         width: 250px;
         letter-spacing: 1px;
        }
    </style>

        <script>
            $(document).ready(function(){
                
                var html = '<tr><td><input type="text" name="m-name[]" class="form-control w-big m_name"><input type="hidden" class="m_name_id" name="m-name-id" value=""><label class="text-center"> medicine Name</label><ul id="searchResult"></ul></td><td><input type="text" name="m-strength[]" class="form-control w-small m-strength"><label class="text-center "> Strength</label></td><td><input type="text" name="m-dosage[]" class="form-control w-small m-dosage"><label class="text-center"> Dosage</label></td><td><input type="text" name="m-dosageI[]" class="form-control m-dosageI"><label class="text-center"> Dosage Instruction</label></td><td><input type="text" name="m-duration[]" class="form-control w-small m-duration"><label class="text-center"> Duration & Quantity</label></td><td><input class="btn btn-danger" type="button" name="add" id="remove" value="Remove"></td></tr>';

                var max = 5; 
                var x = 1;

                $('#add').click(function(){
                    if (x <= max) {
                        $('#table_field').append(html);    
                        x++;
                    }
                    
                });

                $('#table_field').on('click','#remove',function(){
                    $(this).closest('tr').remove();
                    x--;
                });

            });
        </script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="background-color: #273746;">
                <h2 class="text-light p-2">Create Prescription</h2>
            </div>
        </div>

        <div class="row">
            <form class="form-inline" method="post" action="formSubmit">
                <?php echo e(@csrf_field()); ?>

                <div class="form-row p-3">
                    <div class="col">
                        <b>Doctor Name:</b>
                        <select class="custom-select w-10" id="d-name">
                            <option selected="">Choose...</option>
                            <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                            <option value="<?php echo e($cat->id); ?>">
                                <?php echo e(ucfirst($cat->name)); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="d-name-id" class="d-name-id">
                    </div>
                    <div class="col">
                        <b>Qualification : </b>
                        <input type="text" name="" class="form-control w-30 d-qualification">
                    </div>
                    <div class="col">
                        <b>Reg No : </b>
                        <input type="text" name="" class="form-control w-30 d-reg">
                    </div>
                    <div class="col">
                        <b>Full Address : </b>
                        <input type="text" name="" class="form-control d-add">
                    </div>
                    <div class="col">
                        <b>Contact : </b>
                        <input type="text" name="" class="form-control d-contact">
                    </div>
                </div>

                <div class="form-row p-3">
                    <div class="col">
                        <b>Patient Name</b>
                        <input type="text" class="form-control w-10" name="p-name">
                    </div>
                    <div class="col">
                        <b>Sex</b>
                        <select class="custom-select w-30">
                            <option selected="">Choose...</option>
                            <option value="1"> Male</option>
                            <option value="2">Female</option>
                            <option value="3">Both</option>
                        </select>
                    </div>
                    <div class="col">
                        <b>Age</b>
                        <input type="text" class="form-control w-30" name="p-age">
                    </div>
                    <div class="col">
                        <b>Weight</b>
                        <input type="text" class="form-control w-30" name="p-weight">
                    </div>
                    <div class="col">
                        <b>Address</b>
                        <textarea name="p-add"></textarea>
                    </div>
                    <div class="col">
                        <b>Mobile Number</b>
                        <input type="text" class="form-control" name="p-number">
                    </div>
                </div>

                <div class="col-md-12 ">
                    <div class="container">
                        <div class="row p-2 border">
                           <div class="col-sm-11">
                                <h3>Medecine</h3>
                            </div>
                            <div class="col-sm-1">
                                <input class="btn btn-warning" type="button" name="add" id="add" value="Add">
                            </div> 
                        </div>
                        <div class="row">
                            <div class="col-md-12 p-0">
                                <div class="input-field">
                                    <table class="table table-bordered" id="table_field">
                                        <tr>
                                            <td>
                                                <input type="text" name="m-name[]" class="form-control w-big m_name">
                                                <input type="hidden" class="m_name_id" name="m-name-id" value="">
                                                <label class="text-center"> medicine Name</label>
                                                <ul id="searchResult"></ul>
                                            </td>
                                            <td>
                                                <input type="text" name="m-strength[]" class="form-control w-small m-strength">
                                                <label class="text-center "> Strength</label>
                                            </td>
                                            <td>
                                                <input type="text" name="m-dosage[]" class="form-control w-small m-dosage">
                                                <label class="text-center"> Dosage</label>
                                            </td>
                                            <td>
                                                <input type="text" name="m-dosageI[]" class="form-control m-dosageI">
                                                <label class="text-center"> Dosage Instruction</label>
                                            </td>
                                            <td>
                                                <input type="text" name="m-duration[]" class="form-control w-small m-duration">
                                                <label class="text-center"> Duration & Quantity</label>
                                            </td>
                                            <td>
                                                <input class="btn btn-danger" type="button" name="add" id="remove" value="Remove">
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>                            
                </div>

                <button class="btn btn-primary" type="submit">Submit form</button>

            </form>
        </div>
    </div>

    <script>
            $(document).ready(function() {

                $('#d-name').on('change',function(){
                    let id = $(this).val();
                    $('.d-name-id').val(id);
                    $.ajax({
                        type:'GET',
                        url: 'd-det/' + id,
                        success: function(response){
                            var response = JSON.parse(response);
                            
                            $('.d-qualification , .d-reg, .d-add, .d-contact').val('');

                            $('.d-qualification').val(response[0].qualification);
                            $('.d-reg').val(response[0].regi_no);
                            $('.d-add').val(response[0].address);
                            $('.d-contact').val(response[0].contact);

                        }
                    });
                });

                function medicine_name()
                {
                    $.ajax({
                        type:'GET',
                        url: 'medicine_det',
                        success: function(response){
                            var response = JSON.parse(response);
                            var item = '<option selected="selected" value="0"> --Select--</option>';

                            $.each(response, function(index, value){
                                // console.log(value['id']);
                                item += "<option value='" + value['id'] +"'>" + value['medicine-name'] + "</option>";
                            });
                        
                            $('#m_data').append(item);                          
                        }
                    });

                }

                $('.m_name').on("keyup", function(){
                    var value =$(this).val();
                    $.ajax({
                        type:'GET',
                        url: 'medicine_det/' + value,
                        success: function(response){
                            var response = JSON.parse(response);
                            $("#searchResult").empty();
                             $.each(response, function(index, value){
                                
                                 $('#searchResult').append("<li class='data_name_m' value ='" + value['id'] + "'>" + value['medicine-name'] + "</li>");
                            });

                             // binding click event to li
                                $("#searchResult li").bind("click",function(){
                                    setText(this);
                                });
                                                    
                        }
                    });

                });

                // Set Text to search box and get details
                function setText(element){
                    $(".m_name_id").empty();
                    var value = $(element).text();
                    var userid = $(element).val();
                    $(".m_name").val(value);
                    $(".m_name_id").val(userid);
                    $("#searchResult").empty();
                    
                    $.ajax({
                        type:'GET',
                        url: 'med_data/' + userid,
                        success: function(response){
                            var response = JSON.parse(response);
                            $.each(response, function(index, value){
                                console.log(value);

                                $('.m-strength , .m-dosage, .m-dosageI, .m-duration').val('');

                                $('.m-strength').val(value['strength']);
                                $('.m-dosage').val(value['dosage-form']);
                                $('.m-dosageI').val(value['d-instruction']);
                                $('.m-duration').val(value['quantity']);
                            });

                            
                        }
                    });                    
                }
                

            });
        </script>

        <script src="https://code.jquery.com/jquery-3.4.1.min.js"  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
        <link href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" rel="Stylesheet"></link>
        
        <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script>
</body>
</html><?php /**PATH E:\xampp\htdocs\Laravel\Project_task\resources\views/home.blade.php ENDPATH**/ ?>