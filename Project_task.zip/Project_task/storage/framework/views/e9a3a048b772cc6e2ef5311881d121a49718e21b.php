<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

	<style type="text/css">
		body{
			font-family: Nunito;
		}
		#emp{
			border-collapse: collapse;
			width: 100%;
			overflow: scroll;
		}
		#emp td,#emp th{
			border: 1px solid #ddd;
			padding: 8px;
		}
	</style>
</head>
<body>
	<table id="emp">
		<thead>
			<tr>
				<th>Patient Name</th>
				<th>Patient Address</th>
				<th>Patient Number</th>
				<th>Patient Sex</th>
				<th>Patient Age</th>
				<th>Patient Weight</th>
				<th>Doctor Name</th>
				<th>Doctor Qualification</th>
				<th>Doctor Address</th>
				<th>Doctor Contact</th>
				<th>Doctor Register</th>
				<th>Medicine Name</th>
				<th>Stdength</th>
				<th>Dosage Form</th>
				<th>Instduction</th>
				<th>Quantity</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<td><?php echo e($value->p_name); ?></td>
				<td><?php echo e($value->p_add); ?></td>
				<td><?php echo e($value->p_num); ?></td>
				<td><?php echo e($value->p_sex); ?></td>
				<td><?php echo e($value->p_age); ?></td>
				<td><?php echo e($value->p_weight); ?></td>
				<td><?php echo e($value->d_name); ?></td>
				<td><?php echo e($value->d_qua); ?></td>
				<td><?php echo e($value->d_add); ?></td>
				<td><?php echo e($value->d_cont); ?></td>
				<td><?php echo e($value->d_reg); ?></td>
				<td><?php echo e($value->medicine_name); ?></td>
				<td><?php echo e($value->strength); ?></td>
				<td><?php echo e($value->dosage_form); ?></td>
				<td><?php echo e($value->d_instruction); ?></td>
				<td><?php echo e($value->quantity); ?></td>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<!-- 37.7952755906px  == 1 cm -->
<!-- width 529.1338582684 -->
<!-- height 793.7007874026  -->
	<div class="prescription_format text-dark" style="background-color: #D7DBDD;width:529.1338582684px;height:793.7007874026px;">
		<div class="doctor_data py-4">
			<div class="row">
				<div class="col-md-12">
					<div class="doctor-content text-center">
						<h5>Ajeet Kumar </h5>
						<label class="doctor_Q text-capitalize">
							Qualification : M.B.B.S
						</label>
						<div class="">
							<div class="doctor-address d-inline">
								Full Address:	
							</div>
							<div class="doctor_C d-inline">
								Contact :
							</div>
						</div>
					</div>

					<div class="row-2 p-2">
						<div class="psn d-inline">
							Prescription Serial Number : D10211
						</div>
						<div class="date d-inline float-right">
							Date : <?php echo date('d-m-Y'); ?>
						</div>
					</div>
					
					<div class="patient-Data mt-3 p-2">
						<div class="p-name">
							Patient Name : Ajeet Kumar
						</div>
						<div class="p-name">
							Patient Address and Phone number : Ajeet Kumar
						</div>
						<div class="p-2">
							<div class="d-inline">
								Sex :
							</div>
							<div class="d-inline">
								Age :
							</div>
							<div class="d-inline">
								Weight :
							</div>							
						</div>						
					</div>

					<div class="p-2">
						<h4>Rx</h4>
					</div>

					<div class="medicine_data">
						<ol type="1">
							<li>Paracetamole 1 dose </li>
						</ol>
					</div>

					<div class="d-sign row">
						<div class="col-md-12">
							<div class="float-right pr-5 mr-5">
								Doctor's Signiture & Date
							</div>
						</div>
							
					</div>
					<div class="d-seal row">
						<div class="col-md-12">
							<div class="float-right pr-5 mr-5">
								Doctor's Stamp
							</div>
						</div>
							
					</div>

					<footer>
						<div class="row w-100">
							<div class="col-md-6">
								<div class="text-left">
									<ul style="list-style-type: none;">
										<li>Dispensed By:</li>
										<li>Name and Address</li>
										<li>Date of dispensing</li>
									</ul>
								</div>
							</div>
							<div class="col-md-6 p-0">
								<div class="float-right">
									<ul style="list-style-type: none;">
										<li>if entire prescription is not dispensed, specify name or number of medicine and quantity dispended.</li>
										<li>
											Name and Address of Medical Store:
										</li>
										<li>
											Date of dispensing:
										</li>
									</ul>
								</div>		
							</div>
						</div>
					</footer>

				</div>
			</div>
		</div>
	</div>
</body>
</html><?php /**PATH E:\xampp\htdocs\Laravel\Project_task\resources\views/view_prescription.blade.php ENDPATH**/ ?>