<!DOCTYPE html>
<html>
<head>
    <title>Dr Prescription</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">


<!-- normal style -->
<style type="text/css">
    input.form-control.w-10, select.custom-select.w-10 {
        width: 250px;
    }
    select.custom-select.w-30 {
        width: 190px;
    }
    input.form-control.w-30 {
        width: 80%;
    }
    textarea {
        width: 235px;
        height: 75px;
    }

    .table-bordered td, .table-bordered th {
         border: none; 
    }


/*medicine style*/
    input.form-control.w-big {
        width: 400px;
    }
    input.form-control.w-small {
        width: 100%;
    }
</style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="background-color: #273746;">
                <h2 class="text-light p-2">Create Prescription</h2>
            </div>
        </div>

        <div class="row">
            <form class="form-inline">

                <div class="form-row p-3">
                    <div class="col">
                        <b>Doctor Name:</b>
                        <select class="custom-select w-10">
                            <option selected="">Choose...</option>
                            <option value="1"> Male</option>
                            <option value="2">Female</option>
                            <option value="3">Both</option>
                        </select>
                    </div>
                    <div class="col">
                        <b>Qualification : </b>
                        <input type="text" name="" class="form-control w-30">
                    </div>
                    <div class="col">
                        <b>Reg No : </b>
                        <input type="text" name="" class="form-control w-30">
                    </div>
                    <div class="col">
                        <b>Full Address : </b>
                        <input type="text" name="" class="form-control">
                    </div>
                    <div class="col">
                        <b>Contact : </b>
                        <input type="text" name="" class="form-control">
                    </div>
                </div>

                <div class="form-row p-3">
                    <div class="col">
                        <b>Patient Name</b>
                        <input type="text" class="form-control w-10" name="p-name">
                    </div>
                    <div class="col">
                        <b>Sex</b>
                        <select class="custom-select w-30">
                            <option selected="">Choose...</option>
                            <option value="1"> Male</option>
                            <option value="2">Female</option>
                            <option value="3">Both</option>
                        </select>
                    </div>
                    <div class="col">
                        <b>Age</b>
                        <input type="text" class="form-control w-30" name="p-age">
                    </div>
                    <div class="col">
                        <b>Weight</b>
                        <input type="text" class="form-control w-30" name="p-weight">
                    </div>
                    <div class="col">
                        <b>Address</b>
                        <textarea name="p-add"></textarea>
                    </div>
                    <div class="col">
                        <b>Mobile Number</b>
                        <input type="text" class="form-control" name="p-number">
                    </div>
                </div>

                <div class="col-md-12 ">
                    <div class="container">
                        <div class="row p-2 border">
                           <div class="col-sm-11">
                                <h3>Medecine</h3>
                            </div>
                            <div class="col-sm-1">
                                <input class="btn btn-warning" type="button" name="add" id="add" value="Add">
                            </div> 
                        </div>
                        <div class="row">
                            <div class="col-md-12 p-0">
                                <div class="input-field">
                                    <table class="table table-bordered" id="table_field">
                                        <tr>
                                            <td>
                                                <input type="text" name="m-name" class="form-control w-big">
                                                <label class="text-center"> medicine Name</label>
                                            </td>
                                            <td>
                                                <input type="text" name="m-strength" class="form-control w-small">
                                                <label class="text-center "> Strength</label>
                                            </td>
                                            <td>
                                                <input type="text" name="m-dosage" class="form-control w-small">
                                                <label class="text-center"> Dosage</label>
                                            </td>
                                            <td>
                                                <input type="text" name="m-dosageI" class="form-control">
                                                <label class="text-center"> Dosage Instruction</label>
                                            </td>
                                            <td>
                                                <input type="text" name="m-duration" class="form-control w-small">
                                                <label class="text-center"> Duration & Quantity</label>
                                            </td>
                                            <td>
                                                <input class="btn btn-danger" type="button" name="add" id="remove" value="Remove">
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>                            
                </div>

                

            </form>
        </div>
    </div>
</body>
</html><?php /**PATH E:\xampp\htdocs\Laravel\Project_task\resources\views/welcome.blade.php ENDPATH**/ ?>